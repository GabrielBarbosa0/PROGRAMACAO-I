lista = []
for i in range(5):
    num = input('Digite um número: ')
    lista.append(num)
print(lista)    